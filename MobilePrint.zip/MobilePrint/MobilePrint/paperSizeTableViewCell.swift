//
//  paperSizeTableViewCell.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 11/22/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class paperSizeTableViewCell: UITableViewCell {

    @IBOutlet weak var paperSizeCellTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
