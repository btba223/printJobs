//
//  selectionVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class selectionVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var jsonDictionary: Dictionary<String, Any>!
    
    var loginResponse:String! //received through segue from login VC
    
    var homeServerURL = "" //to be passed to settingsVC
    
    @IBOutlet weak var selectionTableView: UITableView!
    
    
    @IBOutlet weak var confirmationView: UIView! //Used to hide "Confirm" button if there are no jobs
    
    //Error label
    @IBOutlet weak var confirmationErrorLabel: UILabel!
    
    @IBOutlet weak var noJobsView: UIView!
    @IBOutlet weak var confirmButton: UIButton!
    
    //Print jobs list
    var printJobs: [String] = []
    
    var cellTitleGlobal = "" //cell title to pass to settings view
    var jsonPrintSettingsGlobal = "" //json print settings to send to settings view
    
    //to pass to settingsVC
    var homeServerURLResponse = ""
    var userID = ""
    var accessToken = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        confirmButton.layer.cornerRadius = 5
    }
    
    override func viewWillAppear(_ animated: Bool)
    {        
        selectionTableView.delegate = self
        selectionTableView.dataSource = self
        noJobsView.isHidden = true
        confirmationErrorLabel.isHidden = true
        
        //Convert string to NSData
        let loginResponseData: NSData = loginResponse.data(using: String.Encoding.utf8)! as NSData
        //Convert NSData to AnyObject
        let jsonLoginObject = try? JSONSerialization.jsonObject(with: loginResponseData as Data, options: [])
        //Get data from loginResponse
        accessToken = (jsonLoginObject as! NSDictionary)["access_token"] as! String
        
        //Get home server URL response
        retrieveHomeServerURL(accessToken: accessToken)
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    func retrieveHomeServerURL(accessToken: String) -> Void
    {
        //GET https://lpm-stg.iss.lxk.co/lexmark/api/2.0/profile
        //Header: Authorization = Bearer $access_token
        
        let myUrl = NSURL(string: "https://lpm-stg.iss.lxk.co/lexmark/api/2.0/profile")
        let request = NSMutableURLRequest(url:myUrl! as URL)
        request.httpMethod = "GET"
        request.setValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization")
        //Execute HTTP Request
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        { data, response, error in
            //Check for error
            if error != nil
            {
                print("error = \(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //print("responseString = \(responseString)")
            self.homeServerURLResponse = responseString as! String
            
            //nested 1
            let homeServerURLData: NSData = self.homeServerURLResponse.data(using: String.Encoding.utf8)! as NSData
            let jsonHomeServerObject = try? JSONSerialization.jsonObject(with: homeServerURLData as Data, options: [])
            self.homeServerURL = (jsonHomeServerObject as! NSDictionary)["homeServerUrl"] as! String
            self.userID = (jsonHomeServerObject as! NSDictionary)["userId"] as! String //
            
            //Get print docs
            self.retrievePrintDocs(accessToken: accessToken, homeServerURL: self.homeServerURL, userID: self.userID)
        }
        task.resume()
        
    }
 
    func retrievePrintDocs(accessToken: String, homeServerURL: String, userID: String) -> Void
    {
        //GET $homeServerUrl/api/2.0/users/$userId/printdocs
        //Header: Authorization = Bearer $access_tokenb
        
        let myUrl = NSURL(string: homeServerURL + "/api/2.0/users/" + userID + "/printdocs")
        let request = NSMutableURLRequest(url:myUrl! as URL)
        request.httpMethod = "GET"
        request.setValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization")
        //Execute HTTP Request
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        { data, response, error in
            //Check for error
            if error != nil
            {
                print("error = \(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //print("responseString of print docs = \(responseString)")
            let printDocsResponse = responseString as! String
            
            //nested 2
            self.jsonPrintSettingsGlobal = printDocsResponse
            
            //Get json dictionary
            self.jsonDictionary = self.convertToDictionary(text: printDocsResponse)
            
            print("printing jsonDictionary....")
            print(self.jsonDictionary)
            
            //Get array of print job titles
            self.printJobs = self.getJobTitleArray(jsonDictionary: self.jsonDictionary)
            
            //Dispatch to main thread and fire segue to selection VC
            DispatchQueue.main.async {
                self.selectionTableView.reloadData()
            }
            

        }
        task.resume()
        
    }
    

    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String:Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    func getJobTitleArray(jsonDictionary: Dictionary<String, Any>) -> [String]
    {
        var printJobs: [String] = []
        
        if let embedded = jsonDictionary["_embedded"] as? Any{
            var embeddedDictionary = embedded as! Dictionary<String, Any>
            
            if let printjobs = embeddedDictionary["printdocs"] as? [Any]
            {
                //Loop through each job and append to job array
                for job in printjobs
                {
                    var printjobDictionary = job as! Dictionary<String, Any>
                    if let title = printjobDictionary["title"] as? String
                    {
                        printJobs.append(title)
                    }
                }
            }
        }
        return printJobs
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //TABLEVIEW FUNCTIONS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        //return the size of the array of print jobs
        return printJobs.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //Set each cell's label to the print job name
        let cell = tableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
        
        //Configure cell
        cell.cellTitle?.text = printJobs[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) //When user clicks on a cell
    {
        //let cell = tableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
        
        cellTitleGlobal = printJobs[indexPath.row]
        super.performSegue(withIdentifier: "settingsSegue", sender: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat //Initialize cell height
    {
        return 70
    }
    
    
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        //Can change to 26 later if Lexmark wants to organize print jobs alphabetically
        return 1
    }

    
    @IBAction func clickedConfirm(_ sender: Any)
    {
        var didSelectJobs = false
        var checkedList: [Bool] = [] //checked list to send to confirmation view
        for cell in selectionTableView.visibleCells
        {
            if let customCell = cell as? SelectionTableViewCell
            {
                checkedList.append(customCell.isChecked)
            }
        }
        
        //check the checkedList array to see if there are any true
        for item in checkedList
        {
            if(item == true)
            {
                didSelectJobs = true
            }
        }
        
        //if there are selected jobs, segue to confirmation view
        if(didSelectJobs == true)
        {
            confirmationErrorLabel.isHidden = true
            self.performSegue(withIdentifier: "confirmationSegue", sender: nil)
        }
        else //else, display message saying no jobs were selected
        {
            //display error message
            confirmationErrorLabel.isHidden = false
            
        }
    }
    
    
    //Prepare for the next view to appear and pass variables to the view
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //If segue to confirmation view
        if(segue.identifier == "confirmationSegue")
        {
            //Pass cell attributes
            let vc = (segue.destination as! confirmationVC)
            vc.allJobs = printJobs
            vc.loginResponse = loginResponse
            
            var checkedList: [Bool] = [] //checked list to send to confirmation view
            for cell in selectionTableView.visibleCells
            {
                if let customCell = cell as? SelectionTableViewCell
                {
                    checkedList.append(customCell.isChecked)
                }
            }
            
            vc.checkedArray = checkedList
            
            let backItem = UIBarButtonItem()
            backItem.title = "Back"
            navigationItem.backBarButtonItem = backItem
            
        }
        else if(segue.identifier == "settingsSegue")
        {
            let vc = (segue.destination as! settingsVC)
            //Pass off print job title and settings options for this cell
            vc.jobTitle = cellTitleGlobal
            vc.jsonPrintSettings = jsonPrintSettingsGlobal
            
            vc.homeServerURL = homeServerURL
            vc.userID = userID
            vc.accessToken = accessToken
            
            vc.jsonDictionary = jsonDictionary
            
            let backItem = UIBarButtonItem()
            backItem.title = "Save"
            navigationItem.backBarButtonItem = backItem
            
        }
        else if(segue.identifier == "addPrintJobSegue")
        {
            let vc = (segue.destination as! addJobVC)
            vc.username = userID
            vc.accessToken = accessToken
            
            let backItem = UIBarButtonItem()
            backItem.title = "Back"
            navigationItem.backBarButtonItem = backItem
        }
    }
    
    //For after user prints jobs and returns to selectionVC
    @IBAction func unwindToSelectionVC (unwindSegue: UIStoryboardSegue)
    {
        //DO NOT REMOVE THIS FUNCTION! 
        //This function is needed in order for the user to redirect back to selection view after printing jobs.
        
    }
    
    

}
