//
//  selectionVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class selectionVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
//class selectionVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    //Variables received through segue
    var username:String!
    
    @IBOutlet weak var selectionTableView: UITableView!
    
    //Print jobs list
    var printJobs: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        selectionTableView.delegate = self
        selectionTableView.dataSource = self
        
        //Get list of print jobs
        printJobs = ["Job 1 ", "Job 2", "Job 3", "Job 4", "Job 5", "Job 6", "Job 7", "Job 8", "Job 9", "Job 10", "Job 11", "Job 12", "Job 13", "Job 14", "Job 15"]
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //TABLEVIEW FUNCTIONS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return printJobs.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
        
        
        //Configure cell
        cell.cellTitle?.text = printJobs[indexPath.row]
        
        return cell
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        //Expand drop-down menu
        let cell = selectionTableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
        
        
        
        
        
        
        NSLog("ASDLKFJASD;FLKASDJS;LKDF")
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }

    
    func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if(segue.identifier == "confirmationSegue")
        {
            let vc = (segue.destination as! confirmationVC)
            vc.selectedJobs = printJobs
        }
    }
    

}
