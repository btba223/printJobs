//
//  selectionVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class selectionVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
//class selectionVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    //Variables received through segue
    var username:String!
    var loginResponse:String!
    
    @IBOutlet weak var selectionTableView: UITableView!
    
    
    //Print jobs list
    var printJobs: [String] = []
    
    var cellTitleGlobal = ""
    var jsonPrintSettingsGlobal = ""
    
    override func viewDidLoad() //called when view is displayed
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        selectionTableView.delegate = self
        selectionTableView.dataSource = self
        
        NSLog("selectionVC username is: " + username)
        NSLog("selectionVC loginResponse is: " + loginResponse)
        
        //Convert string to NSData
        let loginResponseData: NSData = loginResponse.data(using: String.Encoding.utf8)! as NSData
        //var error: NSError?
        //Convert NSData to AnyObject
        let jsonLoginObject = try? JSONSerialization.jsonObject(with: loginResponseData as Data, options: [])
        //Get data from loginResponse
        let accessToken = (jsonLoginObject as! NSDictionary)["access_token"] as! String
        NSLog("access token: " + accessToken)
        
        
        //Get home server URL response
        let homeServerURLResponse = retrieveHomeServerURL(accessToken: accessToken)
        let homeServerURLData: NSData = homeServerURLResponse.data(using: String.Encoding.utf8)! as NSData
        let jsonHomeServerObject = try? JSONSerialization.jsonObject(with: homeServerURLData as Data, options: [])
        let homeServerURL = (jsonHomeServerObject as! NSDictionary)["homeServerUrl"] as! String
        NSLog("home server URL: " + homeServerURL)
        let userID = (jsonHomeServerObject as! NSDictionary)["userId"] as! String //
        NSLog("userID is: " + userID)
        
        //Get print docs
        let printDocsResponse = retrievePrintDocs(accessToken: accessToken, homeServerURL: homeServerURL, userID: userID)
        NSLog("printDocs returned string: " + printDocsResponse)
        jsonPrintSettingsGlobal = printDocsResponse
        
        
        //let printDocsData: NSData = printDocsResponse.data(using: String.Encoding.utf8)! as NSData
        //let jsonPrintDocsObject = try? JSONSerialization.jsonObject(with: printDocsData as Data, options: .mutableContainers)
        //let ID = (jsonPrintDocsObject as! NSDictionary)["id"] as! NSArray //getting error here bc it's a nested json string
        //NSLog("id: " + String(ID))
        
        /*
            //Get job contents -- dependent on if there is an ID in print docs data
            var jobContentsResponse = retrieveJobContents(homeServerURL: homeServerURL, userID: userID, ID: ID, accessToken: accessToken)
            NSLog("Job Contents: " + jobContentsResponse) //binary data of the document
            /* below not needed?
             let jobContentsData: NSData = jobContentsResponse.data(using: String.Encoding.utf8)! as NSData
             let jobContentsObject = try? JSONSerialization.jsonObject(with: jobContentsData as Data, options: [])*/
        */
        
        
        //Get array of print job titles
        printJobs = getJobTitles(jsonString: printDocsResponse)
        //TODO: hide tabeview and output message that there are no jobs if size of this array is 0
        
    }
    
    
    
    func retrieveHomeServerURL(accessToken: String) -> String
    {
        //GET https://lpm-stg.iss.lxk.co/lexmark/api/2.0/profile
        //Header: Authorization = Bearer $access_token
        
        var s = ""
        
        let myUrl = NSURL(string: "https://lpm-stg.iss.lxk.co/lexmark/api/2.0/profile")
        let request = NSMutableURLRequest(url:myUrl! as URL)
        request.httpMethod = "GET"
        request.setValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization")
        //Execute HTTP Request
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        { data, response, error in
            //Check for error
            if error != nil
            {
                print("error = \(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("responseString = \(responseString)")
            s = responseString as! String
        }
        task.resume()
        
        sleep(2)
        return s
    }
 
    func retrievePrintDocs(accessToken: String, homeServerURL: String, userID: String) -> String
    {
        //GET $homeServerUrl/api/2.0/users/$userId/printdocs
        //Header: Authorization = Bearer $access_tokenb
        var s = ""
        
        let myUrl = NSURL(string: homeServerURL + "/api/2.0/users/" + userID + "/printdocs")
        let request = NSMutableURLRequest(url:myUrl! as URL)
        request.httpMethod = "GET"
        request.setValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization")
        //Execute HTTP Request
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        { data, response, error in
            //Check for error
            if error != nil
            {
                print("error = \(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("responseString of print docs = \(responseString)")
            s = responseString as! String
        }
        task.resume()
        
        sleep(3)
        return s
        
        
    }
    
    func retrieveJobContents(homeServerURL: String, userID: String, ID: Int, accessToken: String) -> String
    {
        //GET $homeServerUrl/api/2.0/users/$userId/printdocs/$id/content
        //Header: Authorization = Bearer $access_token
        //Response will be binary data of the document
        
        var s = ""
        
        let myUrl = NSURL(string: homeServerURL + "/api/2.0/users/" + userID + "/printdocs/" + String(ID) + "/content")
        let request = NSMutableURLRequest(url:myUrl! as URL)
        request.httpMethod = "GET"
        request.setValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization")
        //Execute HTTP Request
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        { data, response, error in
            //Check for error
            if error != nil
            {
                print("error = \(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("responseString of job contents = \(responseString)")
            s = responseString as! String
        }
        task.resume()
        
        sleep(2)
        return s
    }
    
    func changePrintSettings()
    {
        //Updating print options for a document is done at the printer, or via the PUT $homeServerUrl/api/2.0/users/$userId/printdocs/$id .  The later will change the options for all future printing.  The former will only apply to the current job
    }
    
    func getJobTitles (jsonString: String) -> [String]
    {
        var tmpArray: [String] = []
        let stringToFind = "\"title\""
        //let strSize = stringToFind.characters.count
        
        var start = 0
        var end = 6
        var substr = ""
        
        var startIndex = jsonString.index(jsonString.startIndex, offsetBy: start)
        var endIndex = jsonString.index(jsonString.startIndex, offsetBy: end)
        
        var charIndexInt = 0
        var charIndex = jsonString.index(jsonString.startIndex, offsetBy: charIndexInt)
        
        while(end != jsonString.characters.count)
        {
            //Find the substring
            startIndex = jsonString.index(jsonString.startIndex, offsetBy: start)
            endIndex = jsonString.index(jsonString.startIndex, offsetBy: end)
            substr = jsonString[startIndex...endIndex]
            //Check if it equals the string to find
            if(substr == stringToFind)
            {
                //Find the print job's name
                var jobTitle = ""
                var c = "string"
                charIndexInt = end
                charIndex = jsonString.index(jsonString.startIndex, offsetBy: charIndexInt)
                while (c != "\"" )
                {
                    
                    c = String(jsonString[charIndex])
                    charIndexInt = charIndexInt + 1
                    charIndex = jsonString.index(jsonString.startIndex, offsetBy: charIndexInt)
                    
                }
                //Append to the job title string
                charIndexInt = charIndexInt + 2
                charIndex = jsonString.index(jsonString.startIndex, offsetBy: charIndexInt)
                c = String(jsonString[charIndex])
                
                while (c != "\"" )
                {
                    jobTitle = jobTitle + c
                    charIndexInt = charIndexInt + 1
                    charIndex = jsonString.index(jsonString.startIndex, offsetBy: charIndexInt)
                    c = String(jsonString[charIndex])
                }
                
                tmpArray.append(jobTitle)
                //print(jobTitle)
            }
            end = end + 1
            start = start + 1
        }
        
        
        return tmpArray
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //TABLEVIEW FUNCTIONS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        //return the size of the array of print jobs
        return printJobs.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //Set each cell's label to the print job name
        let cell = tableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
        
        //Configure cell
        cell.cellTitle?.text = printJobs[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) //When user clicks on a cell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
        
        cellTitleGlobal = printJobs[indexPath.row]
        NSLog("cellTitleGlobal should be: " + cellTitleGlobal)
        super.performSegue(withIdentifier: "settingsSegue", sender: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat //Initialize cell height
    {
        return 45
    }
    
    
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        //Can change to 26 later for if Lexmark wants to organize print jobs alphabetically
        return 1
    }

    
    
    //Prepare for the next view to appear and pass variables to the view
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //If segue to confirmation view
        if(segue.identifier == "confirmationSegue")
        {
            //Pass cell attributes
            let vc = (segue.destination as! confirmationVC)
            vc.selectedJobs = printJobs
            
            var checkedList: [String] = []
            var indexPath: IndexPath!
            var cell: SelectionTableViewCell
            var sectionCount = selectionTableView.numberOfSections
            for section in 0..<sectionCount {
                var rowCount = selectionTableView.numberOfRows(inSection: section)
                for row in 0..<rowCount
                {
                    indexPath = IndexPath(row: row, section: section)
                    let cell = selectionTableView.dequeueReusableCell(withIdentifier: "selectionCellIdentifier", for: indexPath as IndexPath) as! SelectionTableViewCell
                    checkedList.append(cell.cellTitle.text!)//String(cell.isChecked)) //this is returning the initial value
                }
            }
            print("Checkedlist is ...")
            print(checkedList)
            
           
            
            
            
        }
        else if(segue.identifier == "settingsSegue")
        {
            let vc = (segue.destination as! settingsVC)
            //Pass off print job title and settings options for this cell
            vc.jobTitle = cellTitleGlobal
            vc.jsonPrintSettings = jsonPrintSettingsGlobal
            
        }
        else if(segue.identifier == "addPrintJobSegue")
        {
            let vc = (segue.destination as! addJobVC)
            //TODO: pass off array of print settings?
        }
    }
    
    

}
