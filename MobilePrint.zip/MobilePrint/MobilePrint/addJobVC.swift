//
//  addJobVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 11/14/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class addJobVC: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    var username: String!
    var accessToken: String!
    
    @IBOutlet weak var previewImgView: UIImageView!
    
    @IBOutlet weak var selectImgButton: UIButton!
    
    @IBOutlet weak var uploadImgButton: UIButton!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        selectImgButton.layer.cornerRadius = 5
        uploadImgButton.layer.cornerRadius = 5
        uploadImgButton.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func selectImgButtonClicked(_ sender: Any)
    {
        /* gave error
        var image = UIImagePickerController()
        image.delegate = self
        image.sourceType = UIImagePickerControllerSourceType.photoLibrary
        self.present(image, animated: true, completion: nil)*/
        
        
        var photoPicker = UIImagePickerController()
        photoPicker.delegate = self
        photoPicker.sourceType = .photoLibrary
        self.present(photoPicker, animated:true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject])
    {
        uploadImgButton.isHidden = false
        
        let theInfo: NSDictionary = info as NSDictionary
        let img: UIImage = theInfo.object(forKey: UIImagePickerControllerOriginalImage) as! UIImage
        
        print("theInfo is: ")
        print(theInfo)
        
        //display the image selected so user can confirm they selected the correct image
        previewImgView.image = img
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func uploadImage(_ sender: Any)
    {
        //TODO: add image to print job list
        uploadRequest()
        
    }
    
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func uploadRequest()
    {
        /*let url = NSURL(string: "http://lpm-stg-dc.iss.lxk.co/saas/api/2.0/user/"+username+"/printdocs")
        
        let request = NSMutableURLRequest(url: url! as URL)
        request.httpMethod = "POST"
        
        let boundary = "Boundary-\(NSUUID().uuidString)"
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        if (previewImgView.image == nil){
            
            return
        }
        
        //let image_data = UIImageJPEGRepresentation(previewImgView.image!, 1.0)
        let image_data = UIImagePNGRepresentation(previewImgView.image!)
        
        if(image_data == nil){
            return
        }
        
        let body = NSMutableData()
        
        let fname = "test.png"
        let mimetype = "image/png"
        
    
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        
        body.append("Content-Disposition:form-data; name=\"source\"\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append("mobile\r\n".data(using: String.Encoding.utf8)!)
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        
        body.append("Content-Disposition:form-data; name=\"file\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append(image_data!)
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
 
       /*
        body.append("\"source\" : mobile, \"file\" :".data(using: String.Encoding.utf8)!)
        body.append(image_data!)
    */
        
        request.httpBody = body as Data// as Data
        
        let session = URLSession.shared
        
        //Run request
        let task = session.dataTask(with: request as URLRequest)
        {
            (data,  response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else
            {
                print(data)
                print("error uploading image")
                return
            }
            
            let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("ADDING JOB...")
            print(dataString)
            
        }
        
        task.resume()
        
        sleep(8)*/
 
        
        let myUrl = NSURL(string: "http://lpm-stg-dc.iss.lxk.co/saas/api/2.0/user/"+username+"/printdocs");
        //let myUrl = NSURL(string: "http://www.boredwear.com/utils/postImage.php");
        
        let request = NSMutableURLRequest(url:myUrl! as URL);
        request.httpMethod = "POST";
        
        let param = [
            "source"  : "mobile"
        ]
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization") //needed?
        
        
        let imageData = UIImageJPEGRepresentation(previewImgView.image!, 1)
        
        if(imageData==nil)  { return; }
        
        request.httpBody = createBodyWithParameters(parameters: param, filePathKey: "file", imageDataKey: imageData! as NSData, boundary: boundary) as Data
        
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            // You can print out response object
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data = \(responseString!)")
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary
                
                print(json)
                
                DispatchQueue.main.async(execute:{
                    self.previewImgView.image = nil;
                })
                
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
        sleep(8)
        
    }
    
    
    func createBodyWithParameters(parameters: [String: String]?, filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
        let body = NSMutableData();
        
        if parameters != nil
        {
            for (key, value) in parameters!
            {
                //body.append("\"source\" : mobile, \"file\" :".data(using: String.Encoding.utf8)!)
                body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
                
                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: String.Encoding.utf8)!)
                body.append("\(value)\r\n".data(using: String.Encoding.utf8)!)
            }
        }
        
        let filename = "user-profile.jpg"
        let mimetype = "image/jpg"
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append(imageDataKey as Data)
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        
        
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        return body
    }
    
}
