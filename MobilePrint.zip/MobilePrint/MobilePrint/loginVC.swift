//
//  loginVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class loginVC: UIViewController {

    //Username and password text fields
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    //Login button and message label for errors and invalid input
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var invalidCredMsg: UILabel!
    
    var postResponse = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        invalidCredMsg.text = ""
        
        loginButton.layer.cornerRadius = 5
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func loginButtonClicked(_ sender: AnyObject) //When user clicks "login" button
    {
        
        var isValid = false
        
        //let username = "hunter-carnes@hotmail.com" //REMOVE LATER
        //let password = "|>r0j3ctDr4g0n" //REMOVE LATER
        let username = usernameTF.text
        let password = passwordTF.text
        
        //If user didn't enter both, username and password
        if(usernameTF.text!.isEmpty || passwordTF.text!.isEmpty)
        {
            invalidCredMsg.text = "Please enter a username and password."
            return
        }
        //Hardcoded test username & password: REMOVE LATER!
        else if(username == "username" && password == "pwd")
        {
            isValid = true
        }
        else
        {
            isValid = userValidation(username: username!, password: password!)
        }
        
        
        //If credentials are valid, segue to selectionVC
        if(isValid == true)
        {
            super.performSegue(withIdentifier: "loginSegue", sender: nil)
        }
        //Else, output that these are wrong credentials
        else
        {
            invalidCredMsg.text = "Invalid username or password."
        }
    }
    
    func setPostResponse(x: String)
    {
        postResponse = x
    }
    
    func userValidation(username: String, password: String) -> Bool
    {
        var request = URLRequest(url: URL(string: "https://idp-staging.iss.lxk.co/oauth/token")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let postString = "{\"grant_type\":\"password\",\"username\":\""+username+"\",\"password\":\""+password+"\"}" //TODO LATER: add ! at username/pwd
        request.httpBody = postString.data(using: .utf8)
        
        var tmpBool = false
        
        let task = URLSession.shared.dataTask(with: request)
        { data, response, error in
            
            guard let data = data, error == nil else
            {
                //check for fundamental networking error
                print("error=\(error)")
                return
            }
            let httpStatus = response as? HTTPURLResponse
            if httpStatus?.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus?.statusCode)")
                print("response = \(response)")
            }
            else //if statusCode == 200 and credentials are good
            {
                print("HEY! statusCode is \(httpStatus?.statusCode)")
                tmpBool = true
            }
            
            //get the response string
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
            self.setPostResponse(x: responseString!)
        }
        task.resume()
        sleep(1)
        
        NSLog("tmpBool is..." + String(tmpBool))
        NSLog("Response: " + String(postResponse))
        return tmpBool
    }
    
    
    //Prepare for the next view to appear and pass variables to the view
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "loginSegue")
        {
            let vc = (segue.destination as! selectionVC)
            vc.username = usernameTF.text
            vc.loginResponse = postResponse
        }
    }
    
    


}
