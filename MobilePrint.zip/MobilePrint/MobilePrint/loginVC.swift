//
//  loginVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class loginVC: UIViewController, UITextFieldDelegate {

    //Username and password text fields
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    //Login button and message label for errors and invalid input
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var invalidCredMsg: UILabel!
    
    var postResponse = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        invalidCredMsg.text = ""
        
        loginButton.layer.cornerRadius = 5
        
        self.navigationController?.isNavigationBarHidden = true
        
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        invalidCredMsg.text = ""
        usernameTF.text = nil
        passwordTF.text = nil
        self.usernameTF.delegate = self
        self.passwordTF.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return false
    }
    
    
    @IBAction func loginButtonClicked(_ sender: AnyObject) //When user clicks "login" button
    {
        //let username = "hunter-carnes@hotmail.com" //REMOVE LATER
        //let password = "|>r0j3ctDr4g0n" //REMOVE LATER
        let username = usernameTF.text
        let password = passwordTF.text
        //If user didn't enter both, username and password
        if(usernameTF.text!.isEmpty || passwordTF.text!.isEmpty)
        {
            invalidCredMsg.text = "Please enter a username and password."
            return
        }
        else
        {
            userValidation(username: username!, password: password!)
        }
        
        /*var isValid = false
        
        //let username = "hunter-carnes@hotmail.com" //REMOVE LATER
        //let password = "|>r0j3ctDr4g0n" //REMOVE LATER
        let username = usernameTF.text
        let password = passwordTF.text
        
        //If user didn't enter both, username and password
        if(usernameTF.text!.isEmpty || passwordTF.text!.isEmpty)
        {
            invalidCredMsg.text = "Please enter a username and password."
            return
        }
        else
        {
            isValid = userValidation(username: username!, password: password!)
        }
        
        
        //If credentials are valid, segue to selectionVC
        if(isValid == true)
        {
            super.performSegue(withIdentifier: "loginSegue", sender: nil)
        }
        //Else, output that these are wrong credentials
        else
        {
            invalidCredMsg.text = "Invalid username or password."
        }*/
    }
    
    func setPostResponse(x: String)
    {
        postResponse = x
    }
    
    func userValidation(username: String, password: String) -> Void
    {
        
        var request = URLRequest(url: URL(string: "https://idp-staging.iss.lxk.co/oauth/token")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let postString = "{\"grant_type\":\"password\",\"username\":\""+username+"\",\"password\":\""+password+"\"}"
        request.httpBody = postString.data(using: .utf8)

        //Background Task
        let task = URLSession.shared.dataTask(with: request)
        { data, response, error in
            
            guard let data = data, error == nil else
            {
                //check for fundamental networking error
                print("error=\(error)")
                return
            }
            let httpStatus = response as? HTTPURLResponse
            if httpStatus?.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus?.statusCode)")
                print("response = \(response)")
                
                //Dispatch to main thread and display error
                DispatchQueue.main.async {
                    self.invalidCredMsg.text = "Invalid username or password."
                }
            }
                
            else //if statusCode == 200 and credentials are good
            {
                print("statusCode is \(httpStatus?.statusCode)")
                
                //Dispatch to main thread and fire segue to selection VC
                DispatchQueue.main.async {
                    super.performSegue(withIdentifier: "loginSegue", sender: nil)
                }
            }
    
            //get the response string
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
            self.setPostResponse(x: responseString!)
        }
        task.resume()
        
        /*var request = URLRequest(url: URL(string: "https://idp-staging.iss.lxk.co/oauth/token")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let postString = "{\"grant_type\":\"password\",\"username\":\""+username+"\",\"password\":\""+password+"\"}"
        request.httpBody = postString.data(using: .utf8)
        
        var tmpBool = false
        
        let task = URLSession.shared.dataTask(with: request)
        { data, response, error in
            
            guard let data = data, error == nil else
            {
                //check for fundamental networking error
                print("error=\(error)")
                return
            }
            let httpStatus = response as? HTTPURLResponse
            if httpStatus?.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus?.statusCode)")
                print("response = \(response)")
            }
            else //if statusCode == 200 and credentials are good
            {
                print("statusCode is \(httpStatus?.statusCode)")
                tmpBool = true
            }
            
            //get the response string
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
            self.setPostResponse(x: responseString!)
        }
        task.resume()
        sleep(1)
 
        return tmpBool*/
    }
    
    
    //Prepare for the next view to appear and pass variables to the view
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.isNavigationBarHidden = false //display navigation controller
        
        if(segue.identifier == "loginSegue")
        {
            let vc = (segue.destination as! selectionVC)
            vc.loginResponse = postResponse
        }
    }
}
