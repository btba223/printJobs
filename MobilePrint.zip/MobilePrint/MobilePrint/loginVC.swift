//
//  loginVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class loginVC: UIViewController {

    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var invalidCredMsg: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        invalidCredMsg.text = ""
        
        loginButton.layer.cornerRadius = 5
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func loginButtonClicked(_ sender: AnyObject)
    {
        //Validate credentials
        var isValid = false
        if(usernameTF.text!.isEmpty || passwordTF.text!.isEmpty)
        {
            invalidCredMsg.text = "Please enter a username and password."
        }
        else
        {
            if(usernameTF.text == "username" && passwordTF.text == "pwd")
            {
                isValid = true
            }
            //this is where validation code will go!
        }
        
        
        
        //If credentials are valid, segue to selectionVC
        if(isValid == true)
        {
            self.performSegue(withIdentifier: "loginSegue", sender: nil)
        }
            //Else, output that these are wrong credentials
        else
        {
            invalidCredMsg.text = "Invalid username or password."
        }
    }
    
    func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if(segue.identifier == "loginSegue")
        {
            let vc = (segue.destination as! selectionVC)
            vc.username = usernameTF.text
        }
    }


}
