//
//  SelectionTableViewCell.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class SelectionTableViewCell: UITableViewCell {

    @IBOutlet weak var checkboxImgView: UIImageView!
    @IBOutlet weak var cellTitle: UILabel!
    @IBOutlet weak var dropDownImgView: UIImageView!
    @IBOutlet weak var settingsView: UIView!
    @IBOutlet weak var settingsLabel: UILabel!
    
    var isChecked = false
    var isDroppedDown = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        checkboxImgView.image = UIImage(named: "unchecked.png")
        dropDownImgView.image = UIImage(named: "downArrow.png")
        isChecked = false
        isDroppedDown = false
        settingsView.isHidden = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        //IDEA: make a 'drop-down menu', expand the tableview cell instead to display other properties of the cell for print settings: https://littlebitesofcocoa.com/50-expanding-uitableviewcells
        
        if(isDroppedDown)
        {
            //close drop-down menu
            dropDownImgView.image = UIImage(named: "downArrow.png")
            isDroppedDown = false
            settingsView.isHidden = true
        }
        else
        {
            dropDownImgView.image = UIImage(named: "upArrow.png")
            isDroppedDown = true
            settingsView.isHidden = false
        }
        
        
    }
    
    @IBAction func checkboxClicked(_ sender: AnyObject)
    {
        //change checkbox image
        if(isChecked == true)
        {
            isChecked = false
            checkboxImgView.image = UIImage(named: "unchecked.png")
        }
        else
        {
            isChecked = true
            checkboxImgView.image = UIImage(named: "checked.png")
        }
        
        NSLog("clicked checkbox!")
    }

}
