//
//  SelectionTableViewCell.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

//Custom cell in selection view
class SelectionTableViewCell: UITableViewCell {

    @IBOutlet weak var checkboxImgView: UIImageView! //checkbox image
    @IBOutlet weak var cellTitle: UILabel! //cell title (name of print job)
    
    var isChecked = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) //Modify cell if it is selected
    {
        super.setSelected(selected, animated: animated) //animation that cell was selected
        
    }
    
    
    @IBAction func checkboxClicked(_ sender: AnyObject) //Called if user selects print job
    {
        //change checkbox image
        if(isChecked == true)
        {
            isChecked = false
            checkboxImgView.image = UIImage(named: "unchecked.png")
        }
        else
        {
            isChecked = true
            checkboxImgView.image = UIImage(named: "checked.png")
        }
    }
    
    
}
