//
//  selectPaperSizeVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 11/22/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

protocol selectPaperSizeVCDelegate
{
    func acceptData(data: String!)
}

class selectPaperSizeVC: UIViewController, UITableViewDataSource, UITableViewDelegate {

    //variable to send and receive messages to and from settingsVC
    var delegate: selectPaperSizeVCDelegate!
    var data: String?
    
    @IBOutlet weak var paperSizeTableView: UITableView!
    
    let paperTypes: [String] = ["8.5 x 13", "A3", "A4", "A5", "A6", "B5", "Envelope #9", "Envelope #10", "Envelope C5", "Envelope DL", "Envelope Monarch", "Executive", "JIS B4", "JIS B5", "Oficio (Mexico)", "Statement", "Tabloid", "US Legal", "US Letter"]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //TABLEVIEW FUNCTIONS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        //return the size of the array of print jobs
        return paperTypes.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //Set each cell's label to the print job name
        let cell = tableView.dequeueReusableCell(withIdentifier: "paperSizeCellIdentifier", for: indexPath as IndexPath) as! paperSizeTableViewCell
        
        //Configure cell
        cell.paperSizeCellTitle?.text = paperTypes[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) //When user clicks on a cell
    {
        data = paperTypes[indexPath.row]
        self.delegate.acceptData(data: data)
        self.presentingViewController!.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if self.isBeingDismissed
        {
            /*if(data! != nil)
            {
                self.delegate.acceptData(data: data!)
            }
            else
            {
                
            }*/
        }
    }
    

}
