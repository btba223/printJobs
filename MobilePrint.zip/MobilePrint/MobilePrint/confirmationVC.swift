//
//  confirmationVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 10/7/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class confirmationVC: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var loginResponse:String! //to pass to printingStatusVC to be passed back to selection view
    
    //List of selected jobs passed from selectionView
    var allJobs:[String] = []
    var checkedArray:[Bool]!
    var selectedJobs: [String] = []
    
    @IBOutlet weak var confirmationTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        confirmationTableView.delegate = self
        confirmationTableView.dataSource = self
        
        
        //loop through checkedArray and allJobs and append to selectedJobs if allJobs is true
        for i in 0..<checkedArray.count
        {
            if(checkedArray[i] == true)
            {
                selectedJobs.append(allJobs[i])
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //TABLEVIEW FUNCTIONS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return selectedJobs.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "confirmationCellIdentifier", for: indexPath as IndexPath) as! ConfirmationTableViewCell
        
        //Configure cell
        cell.cellTitle?.text = selectedJobs[indexPath.row]
        
        return cell
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat //Initialize cell height
    {
        return 70
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "printStatus")
        {
            let vc = (segue.destination as! printingStatusVC)
            //vc.selectedPaperSize = "B5"
            vc.loginResponse = loginResponse
        }
        
    }
    

    
    
    

}
