//
//  printingStatusVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 11/23/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class printingStatusVC: UIViewController {

    var loginResponse:String! //to pass to selection view
    
    @IBOutlet weak var exitButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        exitButton.layer.cornerRadius = 5
        
        self.navigationController?.isNavigationBarHidden = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        self.navigationController?.isNavigationBarHidden = false //display navigation controller in next view
    }
    

}
