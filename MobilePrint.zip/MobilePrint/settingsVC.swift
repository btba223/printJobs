//
//  settingsVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 11/14/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class settingsVC: UIViewController {

    var jobTitle:String!
    var jsonPrintSettings:String!
    
    @IBOutlet weak var jobTitleLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        jobTitleLabel.text = jobTitle
        
        //TODO: Display the print setting options to current print job settings
        print("Print settings json string: " + jsonPrintSettings)
        //TODO: parse the settings out and assign to variables, and before it segues back to selection view, put those values in the database using HTTP PUT??
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
