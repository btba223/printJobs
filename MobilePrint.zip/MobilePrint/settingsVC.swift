//
//  settingsVC.swift
//  MobilePrint
//
//  Created by Hunter Carnes on 11/14/16.
//  Copyright © 2016 Hunter Carnes. All rights reserved.
//

import UIKit

class settingsVC: UIViewController, UIPopoverPresentationControllerDelegate, selectPaperSizeVCDelegate {
    //Passed from selectionVC
    var jobTitle:String!
    var jsonPrintSettings:String!
    var homeServerURL: String!
    var userID: String!
    var accessToken: String!
    
    @IBOutlet weak var jobTitleLabel: UILabel!
    
    
    //Setting Objects
    @IBOutlet weak var paperSizeButton: UIButton!
    @IBOutlet weak var colorSetting: UISwitch!
    @IBOutlet weak var holePunchSetting: UISwitch!
    @IBOutlet weak var stapleSetting: UISwitch!
    @IBOutlet weak var duplexSetting: UISegmentedControl!
    @IBOutlet weak var nupSetting: UISegmentedControl!
    
    var jsonDictionary: Dictionary<String, Any>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        jobTitleLabel.text = jobTitle
        duplexSetting.layer.cornerRadius = 4.0
        duplexSetting.clipsToBounds = true
        nupSetting.layer.cornerRadius = 4.0
        nupSetting.clipsToBounds = true
        
        colorSetting.layer.cornerRadius = 16.0
        colorSetting.clipsToBounds = true
        holePunchSetting.layer.cornerRadius = 16.0
        holePunchSetting.clipsToBounds = true
        stapleSetting.layer.cornerRadius = 16.0
        stapleSetting.clipsToBounds = true
        
        //Display currently selected settings
        initializeSettings(jsonDictionary: jsonDictionary)
        
        
        print("Print settings json string: " + jsonPrintSettings)
        //TODO: parse the settings out and assign to variables, and before it segues back to selection view, put those values in the database using HTTP PUT??
        
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        //Get values of all the settings
        let color = colorSetting.isOn
        var duplex = false
        if(duplexSetting.selectedSegmentIndex == 1)
        {
            duplex = true
        }
        /*if(duplexSetting.selectedSegmentIndex == 0)
        {
            duplex = "Off"
        }
        else if (duplexSetting.selectedSegmentIndex == 1)
        {
            duplex = "Long-Edge"
        }*/
        let holePunch = holePunchSetting.isOn
        let paperSize = paperSizeButton.currentTitle
        let staple = stapleSetting.isOn
        let tmpNupSelected = nupSetting.selectedSegmentIndex
        var nup = 0
        if(tmpNupSelected == 0)
        {
            nup = 1
        }
        else if(tmpNupSelected == 1)
        {
            nup = 2
        }
        else if(tmpNupSelected == 2)
        {
            nup = 4
        }
        else if(tmpNupSelected == 3)
        {
            nup = 6
        }
        else if(tmpNupSelected == 4)
        {
            nup = 9
        }
        else if(tmpNupSelected == 5)
        {
            nup = 16
        }
                
        print("SETTINGS: ")
        print("color: " + String(color))
        print("duplex: " + String(duplex))
        print("hole punch: " + String(holePunch))
        print("paperSize: " + paperSize!)
        print("staple: " + String(staple))
        print("nup: " + String(nup))
        
        //Modify the dictionary with settings modified in the UI
        jsonDictionary = modifyDictionary(jsonDictionary: jsonDictionary, colorVal: color, duplexVal: duplex, holePunchVal: holePunch, paperSizeVal: paperSize!, stapleVal: staple, nupVal: nup)
        
        //Build parameters string
        let parameters = buildParameterString(color: color, duplex: duplex, holePunch: holePunch, paperSize: paperSize!, staple: staple, nup: nup)
        //print(parameters)
        
        //change settings in system
        var PUTresult = changeSettings(HomeServerUrl: homeServerURL, UserID: userID, accessToken: accessToken, Parameters: parameters)
        print("PUTresult in viewWillDisappear:" + PUTresult)
        
    }
    
    func modifyDictionary(jsonDictionary: Dictionary<String, Any>, colorVal: Bool, duplexVal: Bool, holePunchVal: Bool, paperSizeVal: String, stapleVal: Bool, nupVal: Int) -> Dictionary<String, Any>
    {
        if let embedded = jsonDictionary["_embedded"] as? Any{
            var embeddedDictionary = embedded as! Dictionary<String, Any>
            
            if let printjobs = embeddedDictionary["printdocs"] as? [Any]
            {
                //Loop through each job and modify the print settings
                for job in printjobs
                {
                    var printjobDictionary = job as! NSMutableDictionary
                    if let title = printjobDictionary["title"] as? String
                    {
                        if(title == jobTitle)
                        {
                            //modify print setting values
                            if let isColor = printjobDictionary["color"] as? Bool
                            {
                                printjobDictionary.removeObject(forKey: ["color"])
                                printjobDictionary.addEntries(from: ["color": colorVal])
                            }
                            if let duplex = printjobDictionary["duplex"] as? Bool
                            {
                                printjobDictionary.removeObject(forKey: ["duplex"])
                                printjobDictionary.addEntries(from: ["duplex": duplexVal])
                            }
                            if let holepunch = printjobDictionary["holePunch"] as? Bool
                            {
                                printjobDictionary.removeObject(forKey: ["holePunch"])
                                printjobDictionary.addEntries(from: ["holePunch": holePunchVal])
                            }
                            if let papersize = printjobDictionary["paperSize"] as Any?
                            {
                                printjobDictionary.removeObject(forKey: ["paperSize"])
                                printjobDictionary.addEntries(from: ["paperSize": paperSizeVal])
                            }
                            if let staple = printjobDictionary["staple"] as? Bool
                            {
                                printjobDictionary.removeObject(forKey: ["staple"])
                                printjobDictionary.addEntries(from: ["staple": stapleVal])
                            }
                            if let nup = printjobDictionary["nup"] as? Int
                            {
                                printjobDictionary.removeObject(forKey: ["nup"])
                                printjobDictionary.addEntries(from: ["nup": nupVal])
                            }
                        }
                    }
                }
            }
        }
        return jsonDictionary
    }
    
    func getID(jsonDictionary: Dictionary<String,Any>) -> Int
    {
        var id = 0
        if let embedded = jsonDictionary["_embedded"] as? Any
        {
            var embeddedDictionary = embedded as! Dictionary<String, Any>
            
            if let printjobs = embeddedDictionary["printdocs"] as? [Any]
            {
                //Loop through each job
                for job in printjobs
                {
                    var printjobDictionary = job as! Dictionary<String, Any>
                    if let title = printjobDictionary["title"] as? String
                    {
                        if(title == jobTitle)
                        {
                            if let IDnum = printjobDictionary["id"] as? Int
                            {
                                id = IDnum
                            }
                        }
                    }
                }
            }
        }
        return id
    }
    
    func buildParameterString(color: Bool, duplex: Bool, holePunch: Bool, paperSize: String, staple: Bool, nup: Int) -> String
    {
        let parameterString: [String: Any] = [
            "color" : color,
            "duplex" : duplex,
            "nup" : nup,
            "holePunch" : holePunch,
            "paperSize" : paperSize,
            "staple" : staple
        ]
        
        return String(describing: parameterString)
    }
    
    //TODO: make this work
    var backgroundTask: UIBackgroundTaskIdentifier = UIBackgroundTaskInvalid
    func endBackgroundTask() {
        NSLog("Background task ended.")
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = UIBackgroundTaskInvalid
    }
    var retStr = "FAILED TO CHANGE RETURNED STRING"
    func changeSettings(HomeServerUrl: String, UserID: String, accessToken: String, Parameters: String) -> String
    {
        //PUT $homeServerUrl/api/2.0/users/$userId/printdocs/$id
        //Header: Authorization = Bearer $access_token
        
        let id = getID(jsonDictionary: jsonDictionary)
        //set up URL request
        let todoEndpoint: String = HomeServerUrl + "/api/2.0/users/" + UserID + "/printdocs/" + String(id)
        guard let url = URL(string: todoEndpoint) else //guard checks that the url is valid
        {
            print("Error: cannot create URL")
            return ""
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "PUT" //added
        urlRequest.setValue("Bearer " + accessToken, forHTTPHeaderField: "Authorization") //added
        
        let session = URLSession.shared //create url session to use to send the request
        
        let myCompletionHandler: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
            // this is where the completion handler code goes
            if let response = response {
                print("myCompletionHandler: THIS IS WHAT I SHOULD RETURN: ")
                print(response)
                print("END OF RESPONSE")
                self.retStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue) as! String
                print(self.retStr)
                self.endBackgroundTask()
                return
                
            }
            if let error = error {
                print("myCompletionHandler: ERROR: ")
                print(error)
            }
        }
        let task = session.dataTask(with: urlRequest, completionHandler: myCompletionHandler)
        task.resume()
        
        return self.retStr
    }
    
    func initializeSettings(jsonDictionary: Dictionary<String, Any>)
    {
        
        if let embedded = jsonDictionary["_embedded"] as? Any{
            var embeddedDictionary = embedded as! Dictionary<String, Any>
            
            if let printjobs = embeddedDictionary["printdocs"] as? [Any]
            {
                //Loop through each job and output the settings
                for job in printjobs
                {
                    var printjobDictionary = job as! Dictionary<String, Any>
                    if let title = printjobDictionary["title"] as? String
                    {
                        print("Title: " + title)
                        if(jobTitle == title)
                        {
                            if let color = printjobDictionary["color"] as? Bool
                            {
                                if(color)
                                {
                                    colorSetting.isOn = true
                                }
                                else
                                {
                                    colorSetting.isOn = false
                                }
                            }
                            if let duplex = printjobDictionary["duplex"] as? Bool
                            {
                                if(duplex)
                                {
                                    duplexSetting.selectedSegmentIndex = 1
                                }
                                else
                                {
                                    duplexSetting.selectedSegmentIndex = 0
                                }
                            }
                            if let holepunch = printjobDictionary["holePunch"] as? Bool
                            {
                                if(holepunch)
                                {
                                    holePunchSetting.isOn = true
                                }
                                else
                                {
                                    holePunchSetting.isOn = false
                                }
                            }
                            if let papersize = printjobDictionary["paperSize"] as Any?
                            {
                                if(String(describing: papersize) == "<null>")
                                {
                                    paperSizeButton.setTitle("8.5 x 13", for: .normal)
                                }
                                else
                                {
                                    paperSizeButton.setTitle(String(describing: papersize), for: .normal)
                                }
                            }
                            if let staple = printjobDictionary["staple"] as? Bool
                            {
                                if(staple)
                                {
                                    stapleSetting.isOn = true
                                }
                                else
                                {
                                    stapleSetting.isOn = false
                                }
                            }
                            if let nup = printjobDictionary["nup"] as? Int
                            {
                                if(nup == 1)
                                {
                                    nupSetting.selectedSegmentIndex = 0
                                }
                                else if(nup == 2)
                                {
                                    nupSetting.selectedSegmentIndex = 1
                                }
                                else if(nup == 4)
                                {
                                    nupSetting.selectedSegmentIndex = 2
                                }
                                else if(nup == 6)
                                {
                                    nupSetting.selectedSegmentIndex = 3
                                }
                                else if(nup == 9)
                                {
                                    nupSetting.selectedSegmentIndex = 4
                                }
                                else if(nup == 16)
                                {
                                    nupSetting.selectedSegmentIndex = 5
                                }
                                else
                                {
                                    nupSetting.selectedSegmentIndex = 0
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func clickedToSelectPaperSize(_ sender: UIButton) //sender was Any
    {
        let pvc = storyboard?.instantiateViewController(withIdentifier: "selectPaperSizeVC") as! selectPaperSizeVC  //popover view controller
        //pvc.data = "important data sent via delegate!"
        pvc.delegate = self
        pvc.modalPresentationStyle = .popover
        if let popoverController = pvc.popoverPresentationController
        {
            popoverController.sourceView = sender
            popoverController.sourceRect = sender.bounds
            popoverController.permittedArrowDirections = .any
            popoverController.delegate = self
        }
        present(pvc, animated: true, completion: nil)
        
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle
    {
        return UIModalPresentationStyle.none
    }
    
    func acceptData(data: String!) { //Change text of paper size button to what was selected in popover view
        self.paperSizeButton.setTitle(data, for: .normal)
    }
    
}
